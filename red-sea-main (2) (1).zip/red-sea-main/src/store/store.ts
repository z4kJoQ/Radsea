
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User, Product, Category, CartItem } from '@/types';
import { categories, products } from '@/data/sampleData';

interface AppState {
  user: User | null;
  products: Product[];
  categories: Category[];
  cart: CartItem[];
  searchQuery: string;
  
  // Auth actions
  login: (email: string, password: string) => boolean;
  logout: () => void;
  updateUserProfile: (user: Partial<User>) => void;
  
  // Product actions
  addProduct: (product: Product) => void;
  updateProduct: (id: string, update: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  
  // Cart actions
  addToCart: (productId: string, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartItemQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  
  // Search actions
  setSearchQuery: (query: string) => void;

  // Review actions
  addReview: (productId: string, rating: number, comment: string) => void;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      user: null,
      products: products,
      categories: categories,
      cart: [],
      searchQuery: '',
      
      login: (email, password) => {
        // Simple authentication for demo purposes
        if (email === 'abdallhelias@gmail.com' && password === '123456789') {
          set({ user: { 
            id: 'admin',
            email: 'abdallhelias@gmail.com',
            name: 'Admin',
            isAdmin: true,
          }});
          return true;
        } else if (email && password) {
          // Regular user login
          set({ user: { 
            id: 'user-' + Date.now().toString(),
            email: email,
            name: email.split('@')[0],
            isAdmin: false,
          }});
          return true;
        }
        return false;
      },
      
      logout: () => {
        set({ user: null });
      },
      
      updateUserProfile: (userUpdate) => {
        const currentUser = get().user;
        if (currentUser) {
          set({ user: { ...currentUser, ...userUpdate } });
        }
      },
      
      addProduct: (product) => {
        set((state) => ({
          products: [...state.products, product]
        }));
      },
      
      updateProduct: (id, update) => {
        set((state) => ({
          products: state.products.map(p => 
            p.id === id ? { ...p, ...update } : p
          )
        }));
      },
      
      deleteProduct: (id) => {
        set((state) => ({
          products: state.products.filter(p => p.id !== id)
        }));
      },
      
      addToCart: (productId, quantity) => {
        const product = get().products.find(p => p.id === productId);
        if (!product) return;
        
        set((state) => {
          const existingItem = state.cart.find(item => item.productId === productId);
          
          if (existingItem) {
            return {
              cart: state.cart.map(item => 
                item.productId === productId 
                  ? { ...item, quantity: item.quantity + quantity }
                  : item
              )
            };
          } else {
            return {
              cart: [...state.cart, { productId, quantity, product }]
            };
          }
        });
      },
      
      removeFromCart: (productId) => {
        set((state) => ({
          cart: state.cart.filter(item => item.productId !== productId)
        }));
      },
      
      updateCartItemQuantity: (productId, quantity) => {
        set((state) => ({
          cart: state.cart.map(item => 
            item.productId === productId 
              ? { ...item, quantity }
              : item
          )
        }));
      },
      
      clearCart: () => {
        set({ cart: [] });
      },
      
      setSearchQuery: (query) => {
        set({ searchQuery: query });
      },

      addReview: (productId, rating, comment) => {
        const currentUser = get().user;
        if (!currentUser) return;
        
        const review = {
          id: `review-${Date.now()}`,
          userId: currentUser.id,
          userName: currentUser.name,
          productId,
          rating,
          comment,
          date: new Date().toISOString()
        };

        set((state) => ({
          products: state.products.map(product => 
            product.id === productId 
              ? { 
                ...product, 
                reviews: [...product.reviews || [], review],
                rating: calculateAverageRating([...product.reviews || [], review])
              }
              : product
          )
        }));
      },
    }),
    {
      name: 'red-sea-souk-storage',
    }
  )
);

// Helper function to calculate average rating
function calculateAverageRating(reviews: Array<{ rating: number }>) {
  if (!reviews.length) return 0;
  const total = reviews.reduce((sum, review) => sum + review.rating, 0);
  return Math.round((total / reviews.length) * 10) / 10;
}
