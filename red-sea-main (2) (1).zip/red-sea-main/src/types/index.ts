export type User = {
  id: string;
  email: string;
  name: string;
  phone?: string;
  imageUrl?: string;
  isAdmin: boolean;
};

export type Category = {
  id: string;
  name: string;
  arabicName: string;
  slug: string;
  imageUrl?: string;
};

export type Product = {
  id: string;
  name: string;
  arabicName: string;
  description: string;
  arabicDescription: string;
  price: number;
  imageUrl: string;
  categoryId: string;
  rating: number;
  reviews: Review[];
  sizes?: string[];
};

export type Review = {
  id: string;
  userId: string;
  userName: string;
  productId: string;
  rating: number;
  comment: string;
  date: string;
};

export type CartItem = {
  productId: string;
  quantity: number;
  product: Product;
};
