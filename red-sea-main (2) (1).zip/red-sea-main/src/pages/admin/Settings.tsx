
import { useState } from "react";
import AdminLayout from "./AdminLayout";
import { useStore } from "@/store/store";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Settings as SettingsIcon, Store } from "lucide-react";

const settingsSchema = z.object({
  storeName: z.string().min(2, "اسم المتجر يجب أن يكون أكثر من حرفين"),
  storeEmail: z.string().email("البريد الإلكتروني غير صالح"),
  storePhone: z.string().min(10, "رقم الهاتف يجب أن يكون 10 أرقام على الأقل"),
  storeAddress: z.string().min(10, "العنوان يجب أن يكون أكثر من 10 أحرف"),
  storeDescription: z.string().min(20, "الوصف يجب أن يكون أكثر من 20 حرف"),
  enableUserReviews: z.boolean(),
  enableWishlist: z.boolean(),
  showOutOfStock: z.boolean(),
  taxRate: z.string().min(1, "نسبة الضريبة مطلوبة"),
  shippingFee: z.string().min(1, "رسوم الشحن مطلوبة"),
  currency: z.string().min(1, "العملة مطلوبة"),
});

const Settings = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("general");

  const form = useForm<z.infer<typeof settingsSchema>>({
    resolver: zodResolver(settingsSchema),
    defaultValues: {
      storeName: "البحر الأحمر",
      storeEmail: "info@redsea.com",
      storePhone: "+966500000000",
      storeAddress: "جدة، المملكة العربية السعودية",
      storeDescription: "متجر البحر الأحمر للملابس والإكسسوارات",
      enableUserReviews: true,
      enableWishlist: true,
      showOutOfStock: false,
      taxRate: "15",
      shippingFee: "30",
      currency: "SAR",
    },
  });

  const onSubmit = (data: z.infer<typeof settingsSchema>) => {
    console.log(data);
    toast({
      title: "تم حفظ الإعدادات",
      description: "تم حفظ إعدادات المتجر بنجاح",
    });
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">إعدادات المتجر</h1>
          <Button 
            onClick={form.handleSubmit(onSubmit)}
            className="bg-redSea-600 hover:bg-redSea-700"
          >
            حفظ الإعدادات
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-redSea-50">
            <TabsTrigger value="general" className="data-[state=active]:bg-redSea-100">
              <Store className="w-4 h-4 ml-2" />
              عام
            </TabsTrigger>
            <TabsTrigger value="advanced" className="data-[state=active]:bg-redSea-100">
              <SettingsIcon className="w-4 h-4 ml-2" />
              متقدم
            </TabsTrigger>
          </TabsList>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <TabsContent value="general" className="space-y-6">
                <Card className="p-6">
                  <div className="grid gap-6 md:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="storeName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>اسم المتجر</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="storeEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>البريد الإلكتروني</FormLabel>
                          <FormControl>
                            <Input {...field} type="email" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="storePhone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>رقم الهاتف</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="storeAddress"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>عنوان المتجر</FormLabel>
                          <FormControl>
                            <Input {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="storeDescription"
                      render={({ field }) => (
                        <FormItem className="col-span-2">
                          <FormLabel>وصف المتجر</FormLabel>
                          <FormControl>
                            <Textarea {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="advanced" className="space-y-6">
                <Card className="p-6">
                  <div className="grid gap-6 md:grid-cols-2">
                    <FormField
                      control={form.control}
                      name="enableUserReviews"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel>تمكين تقييمات المستخدمين</FormLabel>
                            <FormDescription>
                              السماح للمستخدمين بكتابة تقييمات للمنتجات
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="enableWishlist"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel>تمكين قائمة الرغبات</FormLabel>
                            <FormDescription>
                              السماح للمستخدمين بإضافة منتجات لقائمة الرغبات
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="showOutOfStock"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border p-4">
                          <div className="space-y-0.5">
                            <FormLabel>عرض المنتجات غير المتوفرة</FormLabel>
                            <FormDescription>
                              عرض المنتجات التي نفذت من المخزون
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <div className="space-y-4 col-span-2">
                      <h3 className="text-lg font-medium">إعدادات الدفع والشحن</h3>
                      <div className="grid gap-4 md:grid-cols-3">
                        <FormField
                          control={form.control}
                          name="taxRate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>نسبة الضريبة (%)</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" max="100" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="shippingFee"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>رسوم الشحن</FormLabel>
                              <FormControl>
                                <Input {...field} type="number" min="0" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="currency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>العملة</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="SAR" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                  </div>
                </Card>
              </TabsContent>
            </form>
          </Form>
        </Tabs>
      </div>
    </AdminLayout>
  );
};

export default Settings;
