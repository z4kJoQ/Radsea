
import AdminLayout from "./AdminLayout";
import { useLanguage } from "@/contexts/LanguageContext";
import { useStore } from "@/store/store";
import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, CheckCircle, XCircle, AlertCircle, MoreVertical } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";

// Mock users for demo purposes
const mockUsers = [
  {
    id: "1",
    name: "أحمد محمد",
    email: "ahmed@example.com",
    status: "approved",
    registrationDate: "2023-04-15",
    imageUrl: "",
  },
  {
    id: "2",
    name: "فاطمة علي",
    email: "fatima@example.com", 
    status: "pending",
    registrationDate: "2023-05-20",
    imageUrl: "",
  },
  {
    id: "3",
    name: "خالد حسن",
    email: "khalid@example.com",
    status: "rejected",
    registrationDate: "2023-06-10",
    imageUrl: "",
  },
  {
    id: "4",
    name: "نورا سالم",
    email: "nora@example.com",
    status: "pending",
    registrationDate: "2023-06-25",
    imageUrl: "",
  },
  {
    id: "5",
    name: "محمد أحمد",
    email: "mohammed@example.com",
    status: "approved",
    registrationDate: "2023-07-05",
    imageUrl: "",
  }
];

export default function UserList() {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const [users, setUsers] = useState(mockUsers);
  const [filter, setFilter] = useState("all");

  // Filter users
  const filteredUsers = users.filter(user => {
    // Filter by search
    const matchesSearch = searchQuery 
      ? user.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        user.email.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    
    // Filter by status
    const matchesStatus = filter === "all" ? true : user.status === filter;
    
    return matchesSearch && matchesStatus;
  });

  const handleUpdateStatus = (userId: string, status: 'approved' | 'rejected') => {
    setUsers(users.map(user => 
      user.id === userId ? { ...user, status } : user
    ));
    
    toast.success(`${t("userStatus")} ${t(status)}`);
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">{t("userManagement")}</h1>
          <p className="text-muted-foreground">{t("manageAllUsers")}</p>
        </div>

        <Card>
          <CardHeader className="border-b">
            <div className="flex flex-col md:flex-row gap-4 justify-between">
              <CardTitle>{t("usersList")}</CardTitle>
              
              <div className="flex gap-2">
                <Button 
                  variant={filter === "all" ? "secondary" : "outline"} 
                  size="sm"
                  onClick={() => setFilter("all")}
                >
                  {t("all")}
                </Button>
                <Button 
                  variant={filter === "pending" ? "secondary" : "outline"} 
                  size="sm"
                  onClick={() => setFilter("pending")}
                >
                  <AlertCircle className="h-4 w-4 mr-1" />
                  {t("pending")}
                </Button>
                <Button 
                  variant={filter === "approved" ? "secondary" : "outline"} 
                  size="sm"
                  onClick={() => setFilter("approved")}
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  {t("approved")}
                </Button>
                <Button 
                  variant={filter === "rejected" ? "secondary" : "outline"} 
                  size="sm"
                  onClick={() => setFilter("rejected")}
                >
                  <XCircle className="h-4 w-4 mr-1" />
                  {t("rejected")}
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex flex-col gap-6">
              <div className="relative w-full max-w-sm">
                <Input
                  type="text"
                  placeholder={t("searchUsers")}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              </div>

              <div className="rounded-lg border overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t("user")}</TableHead>
                      <TableHead>{t("email")}</TableHead>
                      <TableHead>{t("registrationDate")}</TableHead>
                      <TableHead>{t("status")}</TableHead>
                      <TableHead className="text-right">{t("actions")}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div className="flex items-center">
                            <Avatar className="h-9 w-9 mr-3">
                              <AvatarImage src={user.imageUrl} alt={user.name} />
                              <AvatarFallback>
                                {user.name.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            <div className="font-medium">{user.name}</div>
                          </div>
                        </TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          {new Date(user.registrationDate).toLocaleDateString('ar-EG')}
                        </TableCell>
                        <TableCell>
                          {user.status === "approved" && (
                            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 flex w-fit items-center gap-1">
                              <CheckCircle className="h-3 w-3" />
                              {t("approved")}
                            </Badge>
                          )}
                          {user.status === "pending" && (
                            <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200 flex w-fit items-center gap-1">
                              <AlertCircle className="h-3 w-3" />
                              {t("pending")}
                            </Badge>
                          )}
                          {user.status === "rejected" && (
                            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 flex w-fit items-center gap-1">
                              <XCircle className="h-3 w-3" />
                              {t("rejected")}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {user.status === "pending" ? (
                            <div className="flex justify-end gap-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="border-green-600 text-green-600 hover:bg-green-50"
                                onClick={() => handleUpdateStatus(user.id, "approved")}
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                {t("approve")}
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="border-red-600 text-red-600 hover:bg-red-50"
                                onClick={() => handleUpdateStatus(user.id, "rejected")}
                              >
                                <XCircle className="h-4 w-4 mr-1" />
                                {t("reject")}
                              </Button>
                            </div>
                          ) : (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                {user.status !== "approved" && (
                                  <DropdownMenuItem onClick={() => handleUpdateStatus(user.id, "approved")}>
                                    <CheckCircle className="h-4 w-4 mr-2 text-green-600" />
                                    {t("approve")}
                                  </DropdownMenuItem>
                                )}
                                {user.status !== "rejected" && (
                                  <DropdownMenuItem onClick={() => handleUpdateStatus(user.id, "rejected")}>
                                    <XCircle className="h-4 w-4 mr-2 text-red-600" />
                                    {t("reject")}
                                  </DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                    {filteredUsers.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-6">
                          {t("noUsersFound")}
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
