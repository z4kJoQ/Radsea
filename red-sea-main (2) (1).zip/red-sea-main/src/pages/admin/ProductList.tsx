import { useState } from "react";
import AdminLayout from "../../components/admin/AdminLayout";
import { useStore } from "@/store/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { 
  Star, 
  Search, 
  Plus, 
  MoreVertical, 
  Pencil, 
  Trash2, 
  ShoppingBag,
  Filter
} from "lucide-react";
import ProductForm from "@/components/admin/ProductForm";
import { Product } from "@/types";
import { useLanguage } from "@/contexts/LanguageContext";
import { 
  Card,
  CardContent
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const ProductList = () => {
  const { products, categories, deleteProduct } = useStore();
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [view, setView] = useState<'grid' | 'list'>('grid');

  const filteredProducts = products.filter(product => {
    const matchesSearch = searchQuery 
      ? product.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        product.arabicName.includes(searchQuery)
      : true;
    
    const matchesCategory = categoryFilter 
      ? product.categoryId === categoryFilter 
      : true;
    
    return matchesSearch && matchesCategory;
  }).sort((a, b) => {
    switch(sortBy) {
      case 'priceAsc':
        return a.price - b.price;
      case 'priceDesc':
        return b.price - a.price;
      case 'nameAsc':
        return a.arabicName.localeCompare(b.arabicName);
      case 'nameDesc':
        return b.arabicName.localeCompare(a.arabicName);
      case 'rating':
        return b.rating - a.rating;
      default: // newest
        return 0; // In a real app, would use creation date
    }
  });

  const handleEdit = (product: Product) => {
    if (selectedProduct?.id === product.id && isEditDialogOpen) {
      return; // Prevent reopening the same dialog
    }
    setSelectedProduct(product);
    setIsEditDialogOpen(true);
  };

  const handleDelete = (productId: string) => {
    if (window.confirm(t("confirmDelete"))) {
      deleteProduct(productId);
      toast.success(t("productDeleted"));
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold">{t("productManagement")}</h1>
            <p className="text-muted-foreground">{t("manageAllProducts")}</p>
          </div>
          <Button onClick={() => setIsAddDialogOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            {t("addProduct")}
          </Button>
        </div>

        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row gap-4 justify-between mb-6">
              <div className="relative flex-1 max-w-md">
                <Input
                  type="text"
                  placeholder={t("searchProducts")}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              </div>
              
              <div className="flex flex-wrap gap-2">
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="w-[160px]">
                    <div className="flex items-center gap-2">
                      <Filter className="h-4 w-4" />
                      <span>{categoryFilter ? categories.find(c => c.id === categoryFilter)?.arabicName : t("allCategories")}</span>
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t("allCategories")}</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category.id} value={category.id}>
                        {category.arabicName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-[160px]">
                    <span>{t("sortBy")}</span>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">{t("newest")}</SelectItem>
                    <SelectItem value="priceAsc">{t("priceLowToHigh")}</SelectItem>
                    <SelectItem value="priceDesc">{t("priceHighToLow")}</SelectItem>
                    <SelectItem value="nameAsc">{t("nameAZ")}</SelectItem>
                    <SelectItem value="nameDesc">{t("nameZA")}</SelectItem>
                    <SelectItem value="rating">{t("topRated")}</SelectItem>
                  </SelectContent>
                </Select>
                
                <div className="flex rounded-md border border-input">
                  <Button
                    variant={view === 'grid' ? 'secondary' : 'ghost'}
                    size="icon"
                    className="rounded-none rounded-l-md"
                    onClick={() => setView('grid')}
                  >
                    <ShoppingBag className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={view === 'list' ? 'secondary' : 'ghost'}
                    size="icon"
                    className="rounded-none rounded-r-md"
                    onClick={() => setView('list')}
                  >
                    <ShoppingBag className="h-4 w-4 rotate-90" />
                  </Button>
                </div>
              </div>
            </div>

            {view === 'grid' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {filteredProducts.map((product) => (
                  <Card key={product.id} className="overflow-hidden">
                    <div className="aspect-square bg-gray-100 relative">
                      <img
                        src={product.imageUrl}
                        alt={product.name}
                        className="object-cover w-full h-full"
                      />
                      <div className="absolute top-2 right-2">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button 
                              variant="secondary" 
                              size="icon" 
                              className="rounded-full h-8 w-8 hover:bg-redSea-600 hover:text-white transition-colors"
                            >
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              className="cursor-pointer hover:bg-redSea-50"
                              onClick={() => handleEdit(product)}
                            >
                              <Pencil className="mr-2 h-4 w-4" />
                              {t("edit")}
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-red-600 cursor-pointer hover:bg-red-50"
                              onClick={() => handleDelete(product.id)}
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              {t("delete")}
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <div className="text-sm text-muted-foreground">
                        {categories.find((c) => c.id === product.categoryId)?.arabicName || "—"}
                      </div>
                      <div className="font-semibold line-clamp-1 mt-1" dir="rtl">
                        {product.arabicName}
                      </div>
                      <div className="flex justify-between items-center mt-2">
                        <div className="font-bold text-redSea-600">
                          {product.price.toLocaleString()} ر.ي
                        </div>
                        <div className="flex items-center text-yellow-500">
                          <Star className="h-4 w-4 fill-yellow-500 mr-1" />
                          <span className="text-xs">{product.rating}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {filteredProducts.length === 0 && (
                  <div className="col-span-full text-center py-12 text-muted-foreground">
                    {t("noProductsFound")}
                  </div>
                )}
              </div>
            ) : (
              <div className="overflow-hidden rounded-lg border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t("product")}</TableHead>
                      <TableHead>{t("category")}</TableHead>
                      <TableHead>{t("price")}</TableHead>
                      <TableHead>{t("rating")}</TableHead>
                      <TableHead className="text-right">{t("actions")}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProducts.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell>
                          <div className="flex items-center">
                            <div className="w-12 h-12 bg-gray-100 rounded overflow-hidden mr-3">
                              <img
                                src={product.imageUrl}
                                alt={product.name}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div>
                              <div className="font-medium">{product.arabicName}</div>
                              <div className="text-sm text-gray-500">
                                {product.name}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          {
                            categories.find((c) => c.id === product.categoryId)
                              ?.arabicName || "—"
                          }
                        </TableCell>
                        <TableCell>{product.price.toLocaleString()} ر.ي</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 fill-yellow-400 mr-1" />
                            <span>{product.rating}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="outline" 
                              size="icon"
                              className="hover:bg-redSea-50 hover:border-redSea-200 transition-colors"
                              onClick={() => handleEdit(product)}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="outline" 
                              size="icon" 
                              className="text-red-600"
                              onClick={() => handleDelete(product.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}

                    {filteredProducts.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-6">
                          {t("noProductsFound")}
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog 
        open={isEditDialogOpen} 
        onOpenChange={(open) => {
          if (!open) {
            setIsEditDialogOpen(false);
            setTimeout(() => setSelectedProduct(null), 200);
          }
        }}
      >
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{t("editProduct")}</DialogTitle>
          </DialogHeader>
          {selectedProduct && (
            <ProductForm
              product={selectedProduct}
              mode="edit"
              onSubmit={() => {
                setIsEditDialogOpen(false);
                setTimeout(() => setSelectedProduct(null), 200);
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{t("addProduct")}</DialogTitle>
          </DialogHeader>
          <ProductForm
            mode="add"
            onSubmit={() => setIsAddDialogOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
};

export default ProductList;
