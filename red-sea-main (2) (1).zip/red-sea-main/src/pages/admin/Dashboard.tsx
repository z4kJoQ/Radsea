
import AdminLayout from "./AdminLayout";
import { useStore } from "@/store/store";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShoppingBag, Users, BarChart2 } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Bar } from "recharts";
import {
  ResponsiveContainer,
  BarChart,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
} from "recharts";

export default function Dashboard() {
  const { products, categories } = useStore();
  const { t } = useLanguage();

  // Sample data for charts
  const salesData = [
    { name: "Jan", amount: 12000 },
    { name: "Feb", amount: 19000 },
    { name: "Mar", amount: 15000 },
    { name: "Apr", amount: 22000 },
    { name: "May", amount: 18000 },
    { name: "Jun", amount: 26000 },
  ];

  // Count products by category
  const productsByCategory = categories.map(category => {
    const count = products.filter(p => p.categoryId === category.id).length;
    return {
      name: category.arabicName,
      count: count
    };
  });

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("totalProducts")}
              </CardTitle>
              <ShoppingBag className="h-4 w-4 text-redSea-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{products.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("totalUsers")}
              </CardTitle>
              <Users className="h-4 w-4 text-redSea-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {t("totalOrders")}
              </CardTitle>
              <BarChart2 className="h-4 w-4 text-redSea-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">89</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="col-span-1 md:col-span-2">
            <CardHeader>
              <CardTitle>{t("analytics")}</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={salesData}>
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar 
                    dataKey="amount" 
                    name={t("sales")} 
                    fill="#c8102e" 
                    radius={[4, 4, 0, 0]} 
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t("products")} {t("byCategory")}</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={productsByCategory} layout="vertical">
                  <XAxis type="number" />
                  <YAxis type="category" dataKey="name" width={120} />
                  <Tooltip />
                  <Bar 
                    dataKey="count" 
                    name={t("products")} 
                    fill="#c8102e" 
                    radius={[0, 4, 4, 0]} 
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>{t("recentOrders")}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3].map((order) => (
                  <div key={order} className="flex justify-between items-center">
                    <div>
                      <div className="font-medium">طلب #{1000 + order}</div>
                      <div className="text-sm text-muted-foreground">
                        {new Date().toLocaleDateString('ar-EG')}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{(order * 1500).toLocaleString()} ر.ي</div>
                      <div className="text-xs px-2 py-1 rounded bg-green-100 text-green-800">
                        مكتمل
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}
