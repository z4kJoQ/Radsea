
import { ReactNode, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useStore } from "@/store/store";
import Sidebar from "@/components/admin/Sidebar";
import { Toaster } from "sonner";

interface AdminLayoutProps {
  children: ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const { user } = useStore();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user || !user.isAdmin) {
      navigate("/admin/login");
    }
  }, [user, navigate]);

  if (!user || !user.isAdmin) {
    return null;
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 bg-gray-50">
        <main className="p-6">{children}</main>
      </div>
      <Toaster position="top-center" />
    </div>
  );
}
