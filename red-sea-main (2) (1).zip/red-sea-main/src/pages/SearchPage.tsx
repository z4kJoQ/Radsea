
import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import Layout from "@/components/layout/Layout";
import ProductGrid from "@/components/products/ProductGrid";
import { useStore } from "@/store/store";

const SearchPage = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get("q") || "";
  const { products, setSearchQuery } = useStore();

  useEffect(() => {
    window.scrollTo(0, 0);
    setSearchQuery(query);
  }, [query, setSearchQuery]);

  const searchResults = query
    ? products.filter(
        (product) =>
          product.name.toLowerCase().includes(query.toLowerCase()) ||
          product.arabicName.includes(query) ||
          product.description.toLowerCase().includes(query.toLowerCase()) ||
          product.arabicDescription.includes(query)
      )
    : [];

  return (
    <Layout>
      <div className="container-custom py-8">
        <h1 className="text-3xl font-heading font-bold mb-2">
          نتائج البحث: {query}
        </h1>
        <p className="text-gray-600 mb-6">
          تم العثور على {searchResults.length} منتج
        </p>

        {searchResults.length > 0 ? (
          <ProductGrid products={searchResults} />
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-600">
              لم يتم العثور على منتجات تطابق بحثك عن "{query}"
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default SearchPage;
