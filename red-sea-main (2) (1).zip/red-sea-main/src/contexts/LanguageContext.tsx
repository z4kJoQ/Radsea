
import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'ar' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

interface StoreFeatures {
  title1: string;
  desc1: string;
  title2: string;
  desc2: string;
  title3: string;
  desc3: string;
}

interface TranslationItem {
  [key: string]: string | StoreFeatures;
}

interface TranslationsType {
  ar: TranslationItem;
  en: TranslationItem;
}

const translations: TranslationsType = {
  ar: {
    home: 'الرئيسية',
    about: 'عن المتجر',
    contact: 'اتصل بنا',
    categories: 'التصنيفات',
    search: 'البحث',
    cart: 'السلة',
    login: 'تسجيل الدخول',
    profile: 'الملف الشخصي',
    logout: 'تسجيل خروج',
    viewMore: 'عرض المزيد',
    welcome: 'مرحباً بكم في متجر البحر الأحمر',
    storeDesc: 'نحن نفخر بتقديم أفضل المنتجات اليمنية الأصيلة',
    language: 'اللغة',
    viewAll: 'عرض الكل',
    price: 'السعر',
    quantity: 'الكمية',
    addToCart: 'إضافة إلى السلة',
    reviews: 'التقييمات',
    writeReview: 'اكتب تقييماً',
    submit: 'إرسال',
    loginRequired: 'يجب تسجيل الدخول',
    similarProducts: 'منتجات مشابهة',
    category: 'الفئة',
    aboutTitle: 'عن المتجر',
    aboutWelcome: 'مرحباً بكم في متجر البحر الأحمر - وجهتكم المفضلة للتسوق في اليمن',
    aboutDescription: 'نحن نفخر بتقديم مجموعة واسعة من المنتجات اليمنية الأصيلة، من الملابس التقليدية إلى المنتجات العصرية. هدفنا هو توفير تجربة تسوق سهلة وموثوقة لعملائنا الكرام.',
    aboutCommitment: 'نلتزم بتقديم أفضل جودة وخدمة عملاء متميزة، ونسعى دائماً لتلبية احتياجات عملائنا وتجاوز توقعاتهم.',
    contactUs: 'اتصل بنا',
    address: 'العنوان',
    addressValue: 'صنعاء، اليمن - شارع الخمسين',
    email: 'البريد الإلكتروني',
    sendMessage: 'أرسل لنا رسالة',
    name: 'الاسم',
    message: 'الرسالة',
    sending: 'جاري الإرسال...',
    send: 'إرسال',
    messageSent: 'تم إرسال الرسالة',
    messageSentDesc: 'شكراً لتواصلك معنا. سنرد عليك في أقرب وقت ممكن.',
    messageError: 'خطأ',
    messageErrorDesc: 'حدث خطأ أثناء إرسال الرسالة. يرجى المحاولة مرة أخرى.',
    browseCategories: 'تصفح الفئات',
    exploreProducts: 'استكشف المنتجات',
    cartEmpty: 'سلة التسوق فارغة',
    returnToShopping: 'العودة للتسوق',
    cartTitle: 'سلة التسوق',
    clearCart: 'إفراغ السلة',
    orderSummary: 'ملخص الطلب',
    total: 'الإجمالي',
    shippingInfo: 'معلومات التوصيل',
    fullName: 'الاسم الكامل',
    phone: 'رقم الهاتف',
    detailedAddress: 'العنوان التفصيلي',
    paymentInfo: 'معلومات الدفع',
    storeFeatures: {
      title1: 'منتجات أصيلة',
      desc1: 'نقدم منتجات يمنية عالية الجودة',
      title2: 'شحن سريع',
      desc2: 'توصيل سريع لجميع مناطق اليمن',
      title3: 'دعم متواصل',
      desc3: 'فريق خدمة العملاء متاح دائماً',
    },
    // Admin dashboard translations
    dashboard: 'لوحة التحكم',
    products: 'المنتجات',
    users: 'المستخدمين',
    orders: 'الطلبات',
    settings: 'الإعدادات',
    analytics: 'التحليلات',
    recentOrders: 'الطلبات الأخيرة',
    totalProducts: 'إجمالي المنتجات',
    totalUsers: 'إجمالي المستخدمين',
    totalOrders: 'إجمالي الطلبات',
    productManagement: 'إدارة المنتجات',
    addProduct: 'إضافة منتج',
    editProduct: 'تعديل منتج',
    deleteProduct: 'حذف منتج',
    uploadImage: 'رفع صورة',
    productName: 'اسم المنتج',
    productDescription: 'وصف المنتج',
    productCategory: 'فئة المنتج',
    productPrice: 'سعر المنتج',
    save: 'حفظ',
    cancel: 'إلغاء',
    confirmDelete: 'هل أنت متأكد من حذف هذا المنتج؟',
    yes: 'نعم',
    no: 'لا',
    userManagement: 'إدارة المستخدمين',
    usersList: 'قائمة المستخدمين',
    userStatus: 'حالة المستخدم',
    approve: 'موافقة',
    reject: 'رفض',
    pending: 'قيد الانتظار',
    approved: 'تمت الموافقة',
    rejected: 'تم الرفض',
    registrationDate: 'تاريخ التسجيل',
  },
  en: {
    home: 'Home',
    about: 'About',
    contact: 'Contact',
    categories: 'Categories',
    search: 'Search',
    cart: 'Cart',
    login: 'Login',
    profile: 'Profile',
    logout: 'Logout',
    viewMore: 'View More',
    welcome: 'Welcome to Red Sea Store',
    storeDesc: 'We are proud to offer the best authentic Yemeni products',
    language: 'Language',
    viewAll: 'View All',
    price: 'Price',
    quantity: 'Quantity',
    addToCart: 'Add to Cart',
    reviews: 'Reviews',
    writeReview: 'Write a Review',
    submit: 'Submit',
    loginRequired: 'Login Required',
    similarProducts: 'Similar Products',
    category: 'Category',
    aboutTitle: 'About Us',
    aboutWelcome: 'Welcome to Red Sea Store - Your Preferred Shopping Destination in Yemen',
    aboutDescription: 'We take pride in offering a wide range of authentic Yemeni products, from traditional clothing to modern items. Our goal is to provide an easy and reliable shopping experience for our valued customers.',
    aboutCommitment: 'We are committed to delivering the best quality and excellent customer service, always striving to meet and exceed our customers\' expectations.',
    contactUs: 'Contact Us',
    address: 'Address',
    addressValue: 'Sanaa, Yemen - Al-Khamseen Street',
    email: 'Email',
    sendMessage: 'Send us a message',
    name: 'Name',
    message: 'Message',
    sending: 'Sending...',
    send: 'Send',
    messageSent: 'Message Sent',
    messageSentDesc: 'Thank you for contacting us. We will respond as soon as possible.',
    messageError: 'Error',
    messageErrorDesc: 'An error occurred while sending the message. Please try again.',
    browseCategories: 'Browse Categories',
    exploreProducts: 'Explore Products',
    cartEmpty: 'Shopping Cart is Empty',
    returnToShopping: 'Return to Shopping',
    cartTitle: 'Shopping Cart',
    clearCart: 'Clear Cart',
    orderSummary: 'Order Summary',
    total: 'Total',
    shippingInfo: 'Shipping Information',
    fullName: 'Full Name',
    phone: 'Phone Number',
    detailedAddress: 'Detailed Address',
    paymentInfo: 'Payment Information',
    storeFeatures: {
      title1: 'Authentic Products',
      desc1: 'We offer high-quality Yemeni products',
      title2: 'Fast Shipping',
      desc2: 'Quick delivery to all regions of Yemen',
      title3: 'Continuous Support',
      desc3: 'Customer service team is always available',
    },
    // Admin dashboard translations
    dashboard: 'Dashboard',
    products: 'Products',
    users: 'Users',
    orders: 'Orders',
    settings: 'Settings',
    analytics: 'Analytics',
    recentOrders: 'Recent Orders',
    totalProducts: 'Total Products',
    totalUsers: 'Total Users',
    totalOrders: 'Total Orders',
    productManagement: 'Product Management',
    addProduct: 'Add Product',
    editProduct: 'Edit Product',
    deleteProduct: 'Delete Product',
    uploadImage: 'Upload Image',
    productName: 'Product Name',
    productDescription: 'Product Description',
    productCategory: 'Product Category',
    productPrice: 'Product Price',
    save: 'Save',
    cancel: 'Cancel',
    confirmDelete: 'Are you sure you want to delete this product?',
    yes: 'Yes',
    no: 'No',
    userManagement: 'User Management',
    usersList: 'Users List',
    userStatus: 'User Status',
    approve: 'Approve',
    reject: 'Reject',
    pending: 'Pending',
    approved: 'Approved',
    rejected: 'Rejected',
    registrationDate: 'Registration Date',
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>('ar');

  useEffect(() => {
    const savedLang = localStorage.getItem('language') as Language;
    if (savedLang) {
      setLanguage(savedLang);
    }
  }, []);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('language', lang);
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  };

  const t = (key: string): string => {
    const translation = translations[language][key];
    if (typeof translation === 'string') {
      return translation;
    } else if (translation !== undefined) {
      // For objects like storeFeatures, we stringify them just to maintain type compatibility
      // In practice these should be accessed with more specific functions
      return key;
    }
    return key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
