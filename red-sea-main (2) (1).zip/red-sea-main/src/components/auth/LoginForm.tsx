
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useStore } from "@/store/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function LoginForm({ isAdmin = false }: { isAdmin?: boolean }) {
  const navigate = useNavigate();
  const { login } = useStore();
  const [email, setEmail] = useState(isAdmin ? "abdallhelias@gmail.com" : "");
  const [password, setPassword] = useState(isAdmin ? "123456789" : "");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const success = login(email, password);
      if (success) {
        toast.success(`تم تسجيل الدخول بنجاح!`);
        navigate(isAdmin ? "/admin" : "/");
      } else {
        toast.error("فشل تسجيل الدخول. يرجى التحقق من بيانات الاعتماد الخاصة بك.");
      }
    } catch (error) {
      console.error(error);
      toast.error("حدث خطأ أثناء تسجيل الدخول");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mx-auto max-w-md space-y-6 p-6 bg-white rounded-lg shadow-md">
      <div className="text-center">
        <h1 className="text-2xl font-bold">
          {isAdmin ? "تسجيل دخول المسؤول" : "تسجيل الدخول"}
        </h1>
        <p className="text-gray-500 mt-2">
          {isAdmin
            ? "قم بتسجيل الدخول للوصول إلى لوحة التحكم"
            : "قم بتسجيل الدخول للوصول إلى حسابك"}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">البريد الإلكتروني</Label>
          <Input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="أدخل بريدك الإلكتروني"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="password">كلمة المرور</Label>
          <Input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="أدخل كلمة المرور"
            required
          />
        </div>

        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? "جار تسجيل الدخول..." : "تسجيل الدخول"}
        </Button>

        {!isAdmin && (
          <div className="text-center mt-4">
            <p>
              ليس لديك حساب؟{" "}
              <Button
                variant="link"
                className="p-0"
                onClick={() => navigate("/register")}
              >
                إنشاء حساب
              </Button>
            </p>
          </div>
        )}
      </form>
    </div>
  );
}
