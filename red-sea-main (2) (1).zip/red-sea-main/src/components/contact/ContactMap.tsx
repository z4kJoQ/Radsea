
import { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

const ContactMap = () => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);

  useEffect(() => {
    if (!mapContainer.current) return;

    // Initialize map
    mapboxgl.accessToken = 'YOUR_MAPBOX_TOKEN'; // User needs to provide their Mapbox token
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [44.2066, 15.3694], // Sana'a coordinates
      zoom: 14
    });

    // Add marker for the store location
    const marker = new mapboxgl.Marker()
      .setLngLat([44.2066, 15.3694]) // Store location in Al-Khamseen Street
      .addTo(map.current);

    // Add navigation controls
    map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');

    return () => {
      map.current?.remove();
    };
  }, []);

  return (
    <div className="w-full h-[400px]">
      <div ref={mapContainer} className="w-full h-full" />
    </div>
  );
};

export default ContactMap;
